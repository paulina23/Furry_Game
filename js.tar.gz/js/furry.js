//furry.js

function Furry(){
    this.x = 0;
    this.y = 0;
    this.direction = 'right';
}

module.exports = Furry;
